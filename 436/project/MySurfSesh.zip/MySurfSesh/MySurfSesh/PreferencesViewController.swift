//
//  PreferencesViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 3/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class PreferencesTableViewCell: UITableViewCell {
    var pref: Preference?
}

class PreferencesViewController: UITableViewController {
    var prefs = [Preference]()
    var user: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if user != nil {
            print("user not nil: from prefssview")
        }
        else {
            print("user is nil: from prefssview")
        }
        
        if let user = user {
            prefs = user.preferences
            tableView.reloadData()
            
            //            Session.getSessionsFromDB(user: user) {
            //                [weak self] (DBSessions: [Session]) in
            //                guard let this = self else {return}
            //
            //                print("DB has \(DBSessions.count) sessions")
            //
            //                DispatchQueue.main.async {
            //                    this.sessions = DBSessions
            //                    this.tableView.reloadData()
            //                }
            //            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return prefs.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SubtitleCell", for: indexPath) as! PreferencesTableViewCell
        
        let pref = prefs[indexPath.row]
        if let name = pref.location?.name {
            if let max = pref.maxHeight {
                if let min = pref.minHeight {
                    cell.textLabel?.text = name
                    cell.detailTextLabel?.text = "\(min) - \(max)"
                }
            }
        }
        cell.pref = pref
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowPrefDetail" {
            if let dest = segue.destination as? DetailedPreferenceViewController {
                if let cell = sender as? PreferencesTableViewCell {
                    dest.pref = cell.pref
                }
            }
        }
        
        print("need to segue to add")
        if segue.identifier == "AddPreference" {
            print("segue to addSession")
            if let dest = segue.destination as? UINavigationController {
                if let controller = dest.topViewController as? NewSessionViewController {
                    print("dest is newSession")
                    if user != nil {
                        print("user is not nil transitioning to newsesh")
                        controller.user = user
                        controller.unwindID = "UnwindToSessions"
                    }
                    else {
                        print("user is nil transitioning to newsesh")
                    }
                }
            }
        }
    }
}
