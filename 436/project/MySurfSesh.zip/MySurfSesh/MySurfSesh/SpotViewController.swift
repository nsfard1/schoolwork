//
//  FirstViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/14/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import UIKit
import MapKit

class SpotViewController: UIViewController, MKMapViewDelegate {
    var user: User?
    private var _spots: [SurfSpot]?

    @IBOutlet var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        mapView.delegate = self
        
        if user != nil {
            print("user not nil: from spotview")
        }
        else {
            print("user is nil: from spotview")
        }
        
        SurfSpot.getSpotsFromDB() {
            [weak self] (spots: [SurfSpot]) in
            guard let this = self else {return}
            print("num spots: \(spots.count)")
            this._spots = spots
            for spot in spots {
                let ann = MKPointAnnotation()
                let coord = CLLocationCoordinate2DMake(spot.lat!, spot.long!)
                ann.coordinate = coord
                ann.title = spot.name!
//                print("adding title: \(spot.name!)")
                
                this.mapView.addAnnotation(ann)
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var view = mapView.dequeueReusableAnnotationView(withIdentifier: "pin")
        if view == nil{
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
            view!.canShowCallout = true
        } else {
            view!.annotation = annotation
        }
        
        view?.leftCalloutAccessoryView = nil
        let btn = UIButton(type: UIButtonType.contactAdd)
        view?.rightCalloutAccessoryView = btn
//        self.mapView.bringSubview(toFront: btn)
        
        return view
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        //I don't know how to convert this if condition to swift 1.2 but you can remove it since you don't have any other button in the annotation view
        if (control as? UIButton)?.buttonType == UIButtonType.contactAdd {
            mapView.deselectAnnotation(view.annotation, animated: false)
            performSegue(withIdentifier: "AddSessionFromMap", sender: view)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddSessionFromMap" {
            if let nav = segue.destination as? UINavigationController {
                if let dest = nav.topViewController as? NewSessionViewController {
                    dest.user = user
                    if let ann = sender as? MKAnnotationView {
                        dest.loc = getSpotFromName(name: (ann.annotation?.title)!)
                    }
                    dest.unwindID = "UnwindToMap"
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func unwindToMap(sender: UIStoryboardSegue) {}
    
    private func getSpotFromName(name: String?) -> SurfSpot? {
        for spot in _spots! {
            if spot.name == name {
                return spot
            }
        }
        
        return nil
    }
}

