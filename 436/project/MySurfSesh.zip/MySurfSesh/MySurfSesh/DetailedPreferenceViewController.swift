//
//  DetailedPreferenceViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 3/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class DetailedPreferenceViewController: UIViewController {
    var pref: Preference?
    
    @IBOutlet weak var locLab: UILabel!
    @IBOutlet weak var minHLab: UILabel!
    @IBOutlet weak var maxHLab: UILabel!
    @IBOutlet weak var swellDirLab: UILabel!
    @IBOutlet weak var maxWindLab: UILabel!
    @IBOutlet weak var windDirLab: UILabel!
    @IBOutlet weak var tideLab: UILabel!
    @IBOutlet weak var minTLab: UILabel!
    @IBOutlet weak var maxTLab: UILabel!
    @IBOutlet weak var weatherLab: UILabel!
    @IBOutlet weak var notifyLab: UILabel!
    
    override func viewDidLoad() {
        if let loc = pref?.location {
            locLab.text = loc.name
        }
        
        if let minH = pref?.minHeight {
            minHLab.text = minH.description
        }
        
        if let maxH = pref?.maxHeight {
            maxHLab.text = maxH.description
        }
        
        if let swellDir = pref?.swellDir {
            swellDirLab.text = swellDir
        }
        
        if let maxW = pref?.maxWind {
            maxWindLab.text = maxW.description
        }
        
        if let windDir = pref?.windDir {
            windDirLab.text = windDir
        }
        
        if let tide = pref?.tide {
            tideLab.text = tide
        }
        
        if let minT = pref?.minTime {
            minTLab.text = minT.description
        }
        
        if let maxT = pref?.maxTime {
            maxTLab.text = maxT.description
        }
        
        if let weather = pref?.weather {
            weatherLab.text = weather
        }
        
        if let notify = pref?.notify {
            notifyLab.text = notify ? "yes" : "no"
        }
    }
}
