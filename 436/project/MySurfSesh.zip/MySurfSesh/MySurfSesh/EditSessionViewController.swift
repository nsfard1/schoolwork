//
//  EditSessionViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class EditSessionViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    private var spots: [SurfSpot]?
    private var locPicker = UIPickerView()
    private var loc: SurfSpot?
    private var rating: Int?
    var user: User?
    var session: Session?
    var sessions: [Session]?
    var index: Int?
    
    @IBOutlet weak var fiveButton: UIButton!
    @IBOutlet weak var fourButton: UIButton!
    @IBOutlet weak var threeButton: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var notesTV: UITextView!
    @IBAction func ratingFive(_ sender: Any) {
        rating = 5
//        grayButtons()
        //        fiveButton.titleLabel?.textColor = UIColor.blue
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star"), for: .normal)
    }
    @IBAction func ratingFour(_ sender: Any) {
        rating = 4
//        grayButtons()
        //        fourButton.titleLabel?.textColor = UIColor.blue
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingThree(_ sender: Any) {
        rating = 3
//        grayButtons()
        //        threeButton.titleLabel?.textColor = UIColor.blue
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingTwo(_ sender: Any) {
        rating = 2
//        grayButtons()
        //        twoButton.titleLabel?.textColor = UIColor.blue
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingOne(_ sender: Any) {
        rating = 1
//        grayButtons()
//        oneButton.titleLabel?.textColor = UIColor.blue
        
        twoButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func endTF(_ sender: UITextField) {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        sender.inputView = datePicker
        datePicker.addTarget(self, action: #selector(NewSessionViewController.endPickerValueChanged(sender:)), for: UIControlEvents.valueChanged)
        if let end = session?.endTime {
            datePicker.date = end
        }
    }
    @IBOutlet weak var endText: UITextField!
    @IBAction func startTF(_ sender: UITextField) {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        sender.inputView = datePicker
        datePicker.addTarget(self, action: #selector(NewSessionViewController.startPickerValueChanged(sender:)), for: UIControlEvents.valueChanged)
        if let start = session?.startTime {
            datePicker.date = start
        }
    }
    @IBOutlet weak var startText: UITextField!
    @IBOutlet weak var locationText: UITextField!
    @IBAction func saveChanges(_ sender: Any) {
        if startText.text == nil || startText.text == "" {
            startText.text = Date().description
        }
        if endText.text == nil || endText.text == "" {
            endText.text = Date().description
        }
        print("save changes")
        
        if let start = startText.text {
            print("start good")
            if let end = endText.text {
                print("end good")
                if notesTV.text == nil {
                    notesTV.text = ""
                }
                if let notes = notesTV.text {
                    print("notes good")
                    sessions?[index!].location = loc
                    sessions?[index!].startTime = getTime(time: start)
                    sessions?[index!].endTime = getTime(time: end)
                    sessions?[index!].rating = rating!
                    sessions?[index!].notes = notes
                    
                    user?.updateSessions(sessions: sessions!)
                }
            }
        }
        
        performSegue(withIdentifier: "UnwindToDetails", sender: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SurfSpot.getSpotsFromDB() {
            [weak self] (spots: [SurfSpot]) in
            guard let this = self else { return }
            
            this.spots = spots
        }
        
        if let location = session?.location {
            loc = location
        }
        
        if let rat = session?.rating {
            rating = rat
        }
        
        locPicker.delegate = self
        locationText.inputView = locPicker
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        grayButtons()
        oneButton.setImage(UIImage(named: "ic_star"), for: .normal)
        
        if let rating = session?.rating {
            switch rating {
            case 1:
                twoButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                break
            case 2:
                twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
                threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                break
            case 3:
                twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
                threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
                fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                break
            case 4:
                twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
                threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
                fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
                fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
                break
            case 5:
                twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
                threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
                fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
                fiveButton.setImage(UIImage(named: "ic_star"), for: .normal)
                break
            default:
                break
            }
        }
        
        if let loc = session?.location {
            if let name = loc.name {
                locationText.text = name
            }
        }
        
        if let start = session?.startTime {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm - MM/dd/yyyy"
            formatter.timeZone = TimeZone.current
            startText.text = formatter.string(from: start)
        }
        
        if let end = session?.endTime {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm - MM/dd/yyyy"
            formatter.timeZone = TimeZone.current
            endText.text = formatter.string(from: end)
        }
        
        if let notes = session?.notes {
            notesTV.text = notes
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "UnwindToDetails" {
            if let dest = segue.destination as? DetailedSessionViewController {
                dest.session = session
            }
        }
    }
    
    func startPickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        formatter.timeZone = TimeZone.current
        startText.text = formatter.string(from: sender.date)
    }
    
    func endPickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        formatter.timeZone = TimeZone.current
        endText.text = formatter.string(from: sender.date)
    }
    
    func numberOfComponents(in: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if let sps = spots {
            return sps.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return spots![row].name!
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        loc = spots![row]
        locationText.text = loc?.name
//        locPicker.isHidden = true
    }
    
    private func grayButtons() {
        oneButton.titleLabel?.textColor = UIColor.gray
        twoButton.titleLabel?.textColor = UIColor.gray
        threeButton.titleLabel?.textColor = UIColor.gray
        fourButton.titleLabel?.textColor = UIColor.gray
        fiveButton.titleLabel?.textColor = UIColor.gray
    }
    
    private func getTime(time: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        formatter.timeZone = TimeZone.current
        return formatter.date(from: time)!
    }
}
