//
//  DetailedSessionViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class DetailedSessionViewController: UIViewController {
    var user: User?
    var session: Session?
    var sessions: [Session]?
    var index: Int?
    
    @IBOutlet weak var notesTV: UITextView!
    @IBOutlet weak var endLabel: UILabel!
    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var locLabel: UILabel!
    @IBOutlet weak var starOne: UIImageView!
    @IBOutlet weak var starTwo: UIImageView!
    @IBOutlet weak var starThree: UIImageView!
    @IBOutlet weak var starFour: UIImageView!
    @IBOutlet weak var starFive: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notesTV.isEditable = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let start = session?.startTime {
            if let end = session?.endTime {
                if let rating = session?.rating {
                    if let loc = session?.location?.name {
                        let formatter = DateFormatter()
                        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
                        formatter.timeZone = TimeZone.current
                        
                        startLabel.text = formatter.string(from: start)
                        endLabel.text = formatter.string(from: end)
                        locLabel.text = loc
                        
                        if let notes = session?.notes {
                            notesTV.text = notes
                        }
                        
                        starOne.image = UIImage(named: "ic_star")
                        
                        if rating == 1 {
                            starTwo.image = UIImage(named: "ic_star_border")
                            starThree.image = UIImage(named: "ic_star_border")
                            starFour.image = UIImage(named: "ic_star_border")
                            starFive.image = UIImage(named: "ic_star_border")
                        }
                        else if rating == 2 {
                            starTwo.image = UIImage(named: "ic_star")
                            starThree.image = UIImage(named: "ic_star_border")
                            starFour.image = UIImage(named: "ic_star_border")
                            starFive.image = UIImage(named: "ic_star_border")
                        }
                        else if rating == 3 {
                            starTwo.image = UIImage(named: "ic_star")
                            starThree.image = UIImage(named: "ic_star")
                            starFour.image = UIImage(named: "ic_star_border")
                            starFive.image = UIImage(named: "ic_star_border")
                        }
                        else if rating == 4 {
                            starTwo.image = UIImage(named: "ic_star")
                            starThree.image = UIImage(named: "ic_star")
                            starFour.image = UIImage(named: "ic_star")
                            starFive.image = UIImage(named: "ic_star_border")
                        }
                        else if rating == 5 {
                            starTwo.image = UIImage(named: "ic_star")
                            starThree.image = UIImage(named: "ic_star")
                            starFour.image = UIImage(named: "ic_star")
                            starFive.image = UIImage(named: "ic_star")
                        }
                        
                        starOne.image = starOne.image?.withRenderingMode(.alwaysTemplate)
                        starTwo.image = starTwo.image?.withRenderingMode(.alwaysTemplate)
                        starThree.image = starThree.image?.withRenderingMode(.alwaysTemplate)
                        starFour.image = starFour.image?.withRenderingMode(.alwaysTemplate)
                        starFive.image = starFive.image?.withRenderingMode(.alwaysTemplate)
                        starOne.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                        starTwo.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                        starThree.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                        starFour.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                        starFive.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                    }
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EditSession" {
            if let dest = segue.destination as? EditSessionViewController {
                dest.user = user
                dest.session = session
                dest.sessions = sessions
                dest.index = index
            }
        }
    }
    
    @IBAction func unwindToDetailedSession(sender: UIStoryboardSegue) {}
}
