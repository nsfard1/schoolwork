//
//  LoginViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/18/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuthUI

class LoginViewController: UIViewController, FUIAuthDelegate {
    var user: User?
    
    override func viewDidAppear(_ animated: Bool) {
        if let userEmail = FIRAuth.auth()?.currentUser?.email {
            user = User()
            print("Email is \(userEmail)")
            user?.setupCallback = {
                [weak self] in
                guard let this = self else { return }
                this.performSegue(withIdentifier: "MainInterface", sender: nil)
            }
        }
        else {
            if let authUI = FUIAuth.defaultAuthUI() {
                authUI.providers = []
                authUI.isSignInWithEmailHidden = false
                authUI.delegate = self
                let vc = authUI.authViewController()
                present(vc, animated: true, completion: nil)
            }
        }
    }
    
    func authUI(_ authUI: FUIAuth, didSignInWith user: FIRUser?, error: Error?) {
        print("Signed in user \(user)")
    }
    
    @IBAction func unwindToLoginController(segue: UIStoryboardSegue)
    {
        do {
            try FIRAuth.auth()?.signOut()
        } catch {
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "MainInterface" {
            if let nav = segue.destination as? UITabBarController {
                if let controllers = nav.viewControllers {
                    if let spotController = controllers[0] as? SpotViewController {
                        spotController.user = user
                    }
                    if let navController = controllers[1] as? UINavigationController {
                        if let sessionsController = navController.topViewController as? SessionsViewController {
                            sessionsController.user = user
                        }
                    }
//                    if let nController = controllers[2] as? UINavigationController {
//                        if let prefsController = nController.topViewController as? PreferencesViewController {
//                            prefsController.user = user
//                        }
//                    }
                }
            }
        }
    }
}
