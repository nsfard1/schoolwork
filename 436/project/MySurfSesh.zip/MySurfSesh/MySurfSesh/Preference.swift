//
//  Preference.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 3/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation

class Preference {
    var location: SurfSpot?
    var maxHeight: Double?
    var minHeight: Double?
    var swellDir: String?
    var maxWind: Double?
    var windDir: String?
    var minTime: Int?
    var maxTime: Int?
    var weather: String?
    var tide: String?
    var notify: Bool?
    
    init(location: SurfSpot?, maxHeight: Double?, minHeight: Double?, swellDir: String?, maxWind: Double?, windDir: String?, minTime: Int?, maxTime: Int?, weather: String?, tide: String?, notify: Bool) {
        self.location = location
        self.maxHeight = maxHeight
        self.minHeight = minHeight
        self.swellDir = swellDir
        self.maxWind = maxWind
        self.windDir = windDir
        self.minTime = minTime
        self.maxTime = maxTime
        self.weather = weather
        self.tide = tide
        self.notify = notify
    }
}
