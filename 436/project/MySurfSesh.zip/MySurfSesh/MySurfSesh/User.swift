//
//  User.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import Firebase

class User {
    private var auth: FIRAuth?
    private var currentUser: FIRUser?
    private var setupComplete = false
    var setupCallback: (() -> Void)? {
        didSet {
            if setupComplete {
                setupCallback?()
            }
        }
    }
    
//    private var _sessionIds = [String]()
//    private var sessionIds: [String] {
//        get {
//            return _sessionIds
//        }
//        set {
//            if let str = currentUser?.uid {
//                FIRDatabase.database().reference(withPath: "users/\(str)/user_sessions").setValue(newValue)
//                _sessionIds = newValue
//            }
//        }
//    }
    
    private var _sessionsData = [[String:Any]]()
    private var _sessions = [Session]()
    var sessions = [Session]()
    
    private var _preferencesData = [[String:Any]]()
    var preferences = [Preference]()
        
//        {
//        get {
//            return _sessions
//        }
//        set {
//            if let str = currentUser?.uid {
//                
//            }
//            
//            
//            var newSessionIds = [String]()
//            for session in newValue {
//                newSessionIds.append(session.id!)
//            }
//            sessionIds = newSessionIds
//            _sessions = newValue
//        }
//    }
    
    init() {
        auth = FIRAuth.auth()
        currentUser = auth?.currentUser
        
        if let str = currentUser?.uid {
            let ref = FIRDatabase.database().reference(withPath: "users/\(str)")
//            ref.child("_init").setValue(1)
            ref.observe(.value) {
                [weak self] (data: FIRDataSnapshot) in
                guard let this = self else {return}
//                print("\(data)")
                if let sns = data.childSnapshot(forPath: "sessions").value as? [[String:Any]] {
                    this._sessionsData = sns
                    this.populateSessions(data: sns)
                }
                
                if let prs = data.childSnapshot(forPath: "preferences").value as? [[String:Any]] {
                    this._preferencesData = prs
                    this.populatePreferences(data: prs)
                }
                
//                if let pn = data.childSnapshot(forPath: "PhoneNumber").value as? String {
//                    this._phoneNumber = pn
//                }
//                this._imagePath = data.childSnapshot(forPath: "ImagePath").value as? String
                if !this.setupComplete {
                    this.setupComplete = true
                    this.setupCallback?()
                }
            }
        }
    }
    
    func addSession(session: Session) {
        sessions.insert(session, at: 0)
        _sessionsData.insert(getDataFromSession(session: session), at: 0)
        
        if let id = currentUser?.uid {
            let ref = FIRDatabase.database().reference(withPath: "users/\(id)/sessions")
            ref.setValue(_sessionsData)
        }
        
        //        let newSessionRef = FIRDatabase.database().reference(withPath: "users/\(user.id)/sessions").childByAutoId()
        //        let newSessionId = newSessionRef.key
        //        print("Called addSessionToDB() and got key: \(newSessionId)")
        
        //        var newSessionData = [
        //            "surf_spot": [
        //                "name": location.name!,
        //                "lat": location.lat!,
        //                "long": location.long!
        //                ] as [String : Any],
        //            "start_time": startTime.description,
        //            "end_time": endTime.description,
        //            "rating": rating
        //        ] as [String : Any]
        //
        //        if notes != nil {
        //            newSessionData["notes"] = notes
        //        }
        
        //        newSessionRef.setValue(newSessionData)
    }
    
    func updateSessions(sessions: [Session]) {
        self.sessions = sessions
        _sessionsData = [[String:Any]]()
        
        for session in sessions {
            _sessionsData.append(getDataFromSession(session: session))
        }
        
        if let id = currentUser?.uid {
            let ref = FIRDatabase.database().reference(withPath: "users/\(id)/sessions")
            ref.setValue(_sessionsData)
        }
    }
    
    private func getDataFromSession(session: Session) -> [String:Any] {
        var newSessionData = [
            "surf_spot": [
                "id": session.location?.id! as Any,
                "name": session.location?.name! as Any,
                "lat": session.location?.lat! as Any,
                "long": session.location?.long! as Any
                ] as [String : Any],
            "start_time": session.startTime?.description as Any,
            "end_time": session.endTime?.description as Any,
            "rating": session.rating as Any
        ] as [String : Any]

        if let notes = session.notes {
            newSessionData["notes"] = notes
        }
        
        return newSessionData
    }
    
    private func populateSessions(data: [[String:Any]]) {
        sessions = [Session]()
        
        for datum in data {
            sessions.append(getSessionFromData(data: datum))
        }
    }
    
    private func populatePreferences(data: [[String:Any]]) {
        preferences = [Preference]()
        
        for datum in data {
            preferences.append(getPreferenceFromData(data: datum))
        }
    }
    
    private func getSessionFromData(data: [String:Any]) -> Session {
        var session: Session?
        var spot: SurfSpot?
        
        var spotData = data["surf_spot"] as! [String:Any]
        
        if let spotId = spotData["id"] as! Int? {
            if let spotName = spotData["name"] as! String? {
                if let spotLat = spotData["lat"] as! Double? {
                    if let spotLong = spotData["long"] as! Double? {
                        spot = SurfSpot(id: spotId, name: spotName, lat: spotLat, long: spotLong)
                    }
                }
            }
        }
        
        if let start = data["start_time"] as! String? {
            if let end = data["end_time"] as! String? {
                if let rating = data["rating"] as! Int? {
                    var notes: String?
                    notes = data["notes"] as! String?
                    
                    session = Session(location: spot!, startTime: start, endTime: end, rating: rating, notes: notes)
                }
            }
        }
        
        return session!
    }
    
    private func getPreferenceFromData(data: [String:Any]) -> Preference {
        var pref: Preference?
        var spot: SurfSpot?
        var minT: Int?
        var maxT: Int?
        
        var spotData = data["surf_spot"] as! [String:Any]
        
        if let spotId = spotData["id"] as! Int? {
            if let spotName = spotData["name"] as! String? {
                if let spotLat = spotData["lat"] as! Double? {
                    if let spotLong = spotData["long"] as! Double? {
                        spot = SurfSpot(id: spotId, name: spotName, lat: spotLat, long: spotLong)
                    }
                }
            }
        }
        
        let minHeight = data["min_height"] as! Double?
        let maxHeight = data["max_height"] as! Double?
        let swellDir = data["swell_dir"] as! String?
        let maxWind = data["max_wind"] as! Double?
        let windDir = data["wind_dir"] as! String?
        let tide = data["tide"] as! String?
        let weather = data["weather"] as! String?
        let minTime = data["min_time"] as! String?
        if minTime != nil {
            minT = Int(minTime!)
        }
        let maxTime = data["max_time"] as! String?
        if maxTime != nil {
            maxT = Int(maxTime!)
        }
        if let notify = data["notify"] as! Bool? {
            pref = Preference(location: spot, maxHeight: maxHeight, minHeight: minHeight, swellDir: swellDir, maxWind: maxWind, windDir: windDir, minTime: minT, maxTime: maxT, weather: weather, tide: tide, notify: notify)
        }
        
        return pref!
    }
    
    private func getDate(fromString string: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss Z"
        return formatter.date(from: string)!
    }
    
    
//    private var _phoneNumber: String = ""
//    var phoneNumber: String {
//        get {
//            return _phoneNumber
//        }
//        set {
//            if newValue != phoneNumber {
//                if let str = currentUser?.uid {
//                    FIRDatabase.database().reference(withPath: "users/\(str)/PhoneNumber").setValue(newValue)
//                }
//            }
//        }
//    }
//    
//    private var _imagePath: String?
//    var imagePath: String? {
//        get {
//            return _imagePath
//        }
//        set {
//            if newValue != imagePath {
//                if let str = currentUser?.uid {
//                    if newValue != nil {
//                        FIRDatabase.database().reference(withPath: "users/\(str)/ImagePath").setValue(newValue)
//                    }
//                    else {
//                        FIRDatabase.database().reference(withPath: "users/\(str)/ImagePath").removeValue()
//                    }
//                }
//            }
//        }
//    }
}
