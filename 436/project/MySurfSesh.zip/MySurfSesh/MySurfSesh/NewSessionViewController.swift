//
//  NewSessionViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class NewSessionViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    private var location: String?
    private var rating: Int = 3
    private var _spots: [SurfSpot]?
    var user: User?
    var loc: SurfSpot?
    var unwindID: String?
    var locPicker = UIPickerView()
    
    @IBOutlet weak var fiveButton: UIButton!
    @IBOutlet weak var fourButton: UIButton!
    @IBOutlet weak var threeButton: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var notesTV: UITextView!
    @IBOutlet weak var startText: UITextField!
    @IBOutlet weak var endText: UITextField!
    @IBOutlet weak var locationText: UITextField!
    
    @IBAction func startTF(_ sender: UITextField) {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        sender.inputView = datePicker
        datePicker.addTarget(self, action: #selector(NewSessionViewController.startPickerValueChanged(sender:)), for: UIControlEvents.valueChanged)
    }
    
    @IBAction func endTF(_ sender: UITextField) {
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = UIDatePickerMode.dateAndTime
        sender.inputView = datePicker
        datePicker.addTarget(self, action: #selector(NewSessionViewController.endPickerValueChanged(sender:)), for: UIControlEvents.valueChanged)
        if let end = endText.text {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm - MM/dd/yyyy"
            formatter.timeZone = TimeZone.current
            datePicker.date = formatter.date(from: end)!
        }
    }
    
    @IBAction func addSession(_ sender: Any) {
        print("adding new session...")
        
        //        let sessionId = Session.addSessionToDB(location: locationId!, startTime: Date(), endTime: Date(), rating: rating, notes: nil)
        //        print("session id: \(sessionId)")
        //
        
        print("start: \(startText.text) --- end: \(endText.text)")
        if startText.text == nil || startText.text == "" {
            startText.text = Date().description
        }
        if endText.text == nil || endText.text == "" {
            endText.text = Date().description
        }
        
        if let start = startText.text {
            if let end = endText.text {
                if notesTV.text == nil {
                    notesTV.text = ""
                }
                if let notes = notesTV.text {
                    Session.addSessionToDB(user: user!, location: loc!, startTime: start, endTime: end, rating: rating, notes: notes)
                }
            }
        }
        print("added session")
        
        if let str = unwindID {
            performSegue(withIdentifier: str, sender: nil)
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        print("about to unwind")
        if let str = unwindID {
            print("\(str)")
            performSegue(withIdentifier: str, sender: nil)
        }
    }
    
    @IBAction func ratingFive(_ sender: Any) {
        print("pressed 5")
        rating = 5
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star"), for: .normal)
    }
    @IBAction func ratingFour(_ sender: Any) {
        rating = 4
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingThree(_ sender: Any) {
        rating = 3
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingTwo(_ sender: Any) {
        rating = 2
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    @IBAction func ratingOne(_ sender: Any) {
        rating = 1
        twoButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SurfSpot.getSpotsFromDB() {
            [weak self] (spots: [SurfSpot]) in
            guard let this = self else {return}
            print("num spots: \(spots.count)")
            this._spots = spots
        }

        if user != nil {
            print("user not nil: from newsesh")
        }
        else {
            print("user is nil: from newsesh")
        }
        
        if loc != nil {
            locationText.text = loc?.name
        }
        
        locPicker.delegate = self
        locationText.inputView = locPicker
        
        oneButton.setImage(UIImage(named: "ic_star"), for: .normal)
        twoButton.setImage(UIImage(named: "ic_star"), for: .normal)
        threeButton.setImage(UIImage(named: "ic_star"), for: .normal)
        fourButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
        fiveButton.setImage(UIImage(named: "ic_star_border"), for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        grayButtons()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func startPickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        formatter.timeZone = TimeZone.current
        startText.text = formatter.string(from: sender.date)
        let endDate = sender.date.addingTimeInterval(3600)
        endText.text = formatter.string(from: endDate)
    }
    
    func endPickerValueChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        formatter.timeZone = TimeZone.current
        endText.text = formatter.string(from: sender.date)
    }
    
    func numberOfComponents(in: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if let spots = _spots {
            return spots.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return _spots![row].name!
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        loc = _spots![row]
        locationText.text = loc?.name
//        locPicker.isHidden = true
    }
    
    private func grayButtons() {
        oneButton.titleLabel?.textColor = UIColor.gray
        twoButton.titleLabel?.textColor = UIColor.gray
        threeButton.titleLabel?.textColor = UIColor.gray
        fourButton.titleLabel?.textColor = UIColor.gray
        fiveButton.titleLabel?.textColor = UIColor.gray
    }
    
    
    //    @IBAction func saveSession(_ sender: Any) {
    //        print("adding new session...")
    //
    ////        let sessionId = Session.addSessionToDB(location: locationId!, startTime: Date(), endTime: Date(), rating: rating, notes: nil)
    ////        print("session id: \(sessionId)")
    ////
    //
    //        Session.addSessionToDB(user: user!, location: loc!, startTime: Date(), endTime: Date(), rating: rating, notes: nil)
    //        print("added session")
    //
    //
    //
    ////        {
    ////            [weak self] (session: Session) in
    ////            guard let this = self else { return }
    ////
    ////            var sessions = this.user?.sessions
    ////            if sessions == nil {
    ////                sessions = [Session]()
    ////            }
    ////
    ////            sessions?.append(session)
    ////
    ////            this.user?.sessions = sessions!
    ////            print("added: \(session.id) to user's sessions")
    ////        }
    //
    ////        if sessions != nil {
    ////            print("adding new session to sessions...")
    ////            sessions?.append(sessionId)
    ////        }
    ////        else {
    ////            print("adding first session!")
    ////            sessions = [String]()
    ////            sessions?.append(sessionId)
    ////        }
    //        
    ////        user?.sessions = sessions!
    //    }

    
//    @IBAction func rateSessionOne(_ sender: Any) {
//        rating = 1
//    }
//    @IBAction func rateSessionTwo(_ sender: Any) {
//        rating = 2
//    }
//    @IBAction func rateSessionThree(_ sender: Any) {
//        rating = 3
//    }
//    @IBAction func rateSessionFour(_ sender: Any) {
//        rating = 4
//    }
//    @IBAction func rateSessionFive(_ sender: Any) {
//        rating = 5
//    }
//    
//    @IBAction func addNewSession(_ sender: Any) {
//        let locationId = 0
//        let sessionId = Session.addSessionToDB(location: locationId, startTime: Date(), endTime: Date(), rating: rating, notes: nil)
//        var sessions = user?.sessions
//        
//        if sessions != nil {
//            sessions?.append(sessionId)
//        }
//        else {
//            sessions = [String]()
//            sessions?.append(sessionId)
//        }
//        
//        user?.sessions = sessions!
//    }
}
