//
//  SecondViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/14/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import UIKit

class SessionsTableViewCell: UITableViewCell {
    @IBOutlet weak var locLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var starTwo: UIImageView!
    @IBOutlet weak var starOne: UIImageView!
    @IBOutlet weak var starThree: UIImageView!
    @IBOutlet weak var starFour: UIImageView!
    @IBOutlet weak var starFive: UIImageView!
    var session: Session?
    var index: Int?
}

class SessionsViewController: UITableViewController {
    var sessions = [Session]()
    var user: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if user != nil {
            print("user not nil: from sessionsview")
        }
        else {
            print("user is nil: from sessionsview")
        }
        
        if let user = user {
            sessions = user.sessions
            tableView.reloadData()
            
//            Session.getSessionsFromDB(user: user) {
//                [weak self] (DBSessions: [Session]) in
//                guard let this = self else {return}
//                
//                print("DB has \(DBSessions.count) sessions")
//                
//                DispatchQueue.main.async {
//                    this.sessions = DBSessions
//                    this.tableView.reloadData()
//                }
//            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sessions.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SubtitleCell", for: indexPath) as! SessionsTableViewCell
        
        let session = sessions[indexPath.row]
        if let name = session.location?.name {
            if let rating = session.rating {
                if let start = session.startTime {
                    let formatter = DateFormatter()
                    formatter.dateFormat = "MM/dd/yyyy"
                    formatter.timeZone = TimeZone.current
                    
                    cell.locLabel.text = name
                    cell.dateLabel.text = formatter.string(from: start)
                    cell.starOne.image = UIImage(named: "ic_star")
                    
                    if rating == 1 {
                        cell.starTwo.image = UIImage(named: "ic_star_border")
                        cell.starThree.image = UIImage(named: "ic_star_border")
                        cell.starFour.image = UIImage(named: "ic_star_border")
                        cell.starFive.image = UIImage(named: "ic_star_border")
                    }
                    else if rating == 2 {
                        cell.starTwo.image = UIImage(named: "ic_star")
                        cell.starThree.image = UIImage(named: "ic_star_border")
                        cell.starFour.image = UIImage(named: "ic_star_border")
                        cell.starFive.image = UIImage(named: "ic_star_border")
                    }
                    else if rating == 3 {
                        cell.starTwo.image = UIImage(named: "ic_star")
                        cell.starThree.image = UIImage(named: "ic_star")
                        cell.starFour.image = UIImage(named: "ic_star_border")
                        cell.starFive.image = UIImage(named: "ic_star_border")
                    }
                    else if rating == 4 {
                        cell.starTwo.image = UIImage(named: "ic_star")
                        cell.starThree.image = UIImage(named: "ic_star")
                        cell.starFour.image = UIImage(named: "ic_star")
                        cell.starFive.image = UIImage(named: "ic_star_border")
                    }
                    else if rating == 5 {
                        cell.starTwo.image = UIImage(named: "ic_star")
                        cell.starThree.image = UIImage(named: "ic_star")
                        cell.starFour.image = UIImage(named: "ic_star")
                        cell.starFive.image = UIImage(named: "ic_star")
                    }
                    
                    cell.starOne.image = cell.starOne.image?.withRenderingMode(.alwaysTemplate)
                    cell.starTwo.image = cell.starTwo.image?.withRenderingMode(.alwaysTemplate)
                    cell.starThree.image = cell.starThree.image?.withRenderingMode(.alwaysTemplate)
                    cell.starFour.image = cell.starFour.image?.withRenderingMode(.alwaysTemplate)
                    cell.starFive.image = cell.starFive.image?.withRenderingMode(.alwaysTemplate)
                    cell.starOne.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                    cell.starTwo.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                    cell.starThree.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                    cell.starFour.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                    cell.starFive.tintColor = UIColor(colorLiteralRed: 0, green: 122/255, blue: 1, alpha: 1)
                }
            }
        }
        cell.session = session
        cell.index = indexPath.row
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            sessions.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
            user?.updateSessions(sessions: sessions)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowSessionDetail" {
            if let dest = segue.destination as? DetailedSessionViewController {
                if let cell = sender as? SessionsTableViewCell {
                    dest.user = user
                    dest.session = cell.session
                    dest.sessions = sessions
                    dest.index = cell.index
                }
            }
        }
        
        print("need to segue to add")
        if segue.identifier == "AddSession" {
            print("segue to addSession")
            if let dest = segue.destination as? UINavigationController {
                if let controller = dest.topViewController as? NewSessionViewController {
                    print("dest is newSession")
                    if user != nil {
                        print("user is not nil transitioning to newsesh")
                        controller.user = user
                        controller.unwindID = "UnwindToSessions"
                    }
                    else {
                        print("user is nil transitioning to newsesh")
                    }
                }
            }
        }
    }
    
    @IBAction func unwindToSessionsList(sender: UIStoryboardSegue) {}
}

