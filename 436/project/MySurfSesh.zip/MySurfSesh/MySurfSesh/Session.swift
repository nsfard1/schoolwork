//
//  Session.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import FirebaseDatabase

class Session {
    var id: String?
    
    var location: SurfSpot?
//        {
//        get {
//            return self.location
//        }
//        set {
//            FIRDatabase.database().reference(withPath: "sessions/\(id)/surf_spot_id").setValue(newValue?.id)
//        }
//    }
    
    var startTime: Date?
//        {
//        get {
//            return self.startTime
//        }
//        set {
//            FIRDatabase.database().reference(withPath: "sessions/\(id)/start_time").setValue(newValue?.description)
//        }
//    }
    
    var endTime: Date?
//        {
//        get {
//            return self.endTime
//        }
//        set {
//            FIRDatabase.database().reference(withPath: "sessions/\(id)/end_time").setValue(newValue?.description)
//        }
//    }
    
    var rating: Int?
//        {
//        get {
//            return self.rating
//        }
//        set {
//            FIRDatabase.database().reference(withPath: "sessions/\(id)/rating").setValue(newValue)
//        }
//    }
    
    var notes: String?
//        {
//        get {
//            return self.notes
//        }
//        set {
//            FIRDatabase.database().reference(withPath: "sessions/\(id)/notes").setValue(newValue)
//        }
//    }
    
    init(location: SurfSpot, startTime: String, endTime: String, rating: Int, notes: String?) {
        self.startTime = getTime(time: startTime)
        self.endTime = getTime(time: endTime)
        self.rating = rating
        self.notes = notes
        self.location = location
        
//        SurfSpot.getSpot(withId: location) {
//            [weak self] (spot: SurfSpot) in
//            guard let this = self else { return }
//            
//            this.location = spot
//            print("added spot to session: \(this.location!.name)")
//            callback?(this)
//        }
    }
    
//    class func getSessionsFromDB(user: User, callback: @escaping ([Session]) -> Void) {
//        var sessions = [Session]()
//        
//        let ref = FIRDatabase.database().reference(withPath: "sessions")
//        ref.observe(.value) {
//            (data: FIRDataSnapshot) in
//            
//            for session in user.sessions {
//                print("found session in user db: \(session)")
//                if let sessionLocId = data.childSnapshot(forPath: "\(session)/surf_spot_id").value as? Int {
//                    print("spot_id: \(sessionLocId)")
//                    if let sessionStart = data.childSnapshot(forPath: "\(session)/start_time").value as? String {
//                        print("start: \(sessionStart)")
//                        if let sessionEnd = data.childSnapshot(forPath: "\(session)/end_time").value as? String {
//                            print("end: \(sessionEnd)")
//                            if let sessionRating = data.childSnapshot(forPath: "\(session)/rating").value as? Int {
//                                print("rating: \(sessionRating)")
//                                var sessionNotes: String?
//                                if let DBNotes = data.childSnapshot(forPath: "\(session)/notes").value as? String? {
//                                    sessionNotes = DBNotes
//                                }
//                                
//                                var sesh: Session?
//                                
//                                if user.sessions.index(of: session) == user.sessions.count - 1 {
//                                    sesh = Session(id: session, location: sessionLocId, startTime: sessionStart, endTime: sessionEnd, rating: sessionRating, notes: sessionNotes) {
//                                        callback(sessions)
//                                    }
//                                }
//                                else {
//                                    sesh = Session(id: session, location: sessionLocId, startTime: sessionStart, endTime: sessionEnd, rating: sessionRating, notes: sessionNotes, callback: nil)
//                                }
//                                
//                                sessions.append(sesh!)
//                                print("new sessions count: \(sessions.count)")
//                            }
//                        }
//                    }
//                }
//            }
//        
////            callback(sessions)
//        }
//    }
    
    class func addSessionToDB(user: User, location: SurfSpot, startTime: String, endTime: String, rating: Int, notes: String?) {
//        let newSessionRef = FIRDatabase.database().reference(withPath: "users/\(user.id)/sessions").childByAutoId()
//        let newSessionId = newSessionRef.key
//        print("Called addSessionToDB() and got key: \(newSessionId)")
        
//        var newSessionData = [
//            "surf_spot": [
//                "name": location.name!,
//                "lat": location.lat!,
//                "long": location.long!
//                ] as [String : Any],
//            "start_time": startTime.description,
//            "end_time": endTime.description,
//            "rating": rating
//        ] as [String : Any]
//        
//        if notes != nil {
//            newSessionData["notes"] = notes
//        }
        
//        newSessionRef.setValue(newSessionData)
        
        let session = Session(location: location, startTime: startTime, endTime: endTime, rating: rating, notes: notes)
        user.addSession(session: session)
//        var sessions = user.sessions
//        sessions.append(session)
//        
//        user.sessions = sessions
    }
    
    func deleteSessionFromDB() {
        
    }
    
    private func getTime(time: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm - MM/dd/yyyy"
        
        if let date = formatter.date(from: time) {
            return date
        }
        
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss Z"
        
        return formatter.date(from: time)!
    }
}
