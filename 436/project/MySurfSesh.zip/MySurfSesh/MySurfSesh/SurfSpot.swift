//
//  SurfSpot.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 2/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import Firebase

class SurfSpot {
    var id: Int?
    var name: String?
    var lat: Double?
    var long: Double?
    
    init(id: Int, name: String, lat: Double, long: Double) {
        self.id = id
        self.name = name
        self.lat = lat
        self.long = long
    }
    
    class func getSpotsFromDB(callback: @escaping ([SurfSpot]) -> Void ) {
        var spots = [SurfSpot]()
        
        let ref = FIRDatabase.database().reference(withPath: "surf_spots")
        ref.observe(.value) {
            (data: FIRDataSnapshot) in
            
            
            
            for child in (data.children.allObjects as? [FIRDataSnapshot])! {
                if let spotName = child.childSnapshot(forPath: "spot_name").value as? String {
                    if let spotLat = child.childSnapshot(forPath: "latitude").value as? Double {
                        if let spotLong = child.childSnapshot(forPath: "longitude").value as? Double {
                            let spot = SurfSpot(id: 0, name: spotName, lat: spotLat, long: spotLong)
//                            print("id: \(spot.id), name: \(spot.name), lat: \(spot.lat), long: \(spot.long)")
                            spots.append(spot)
//                            print("spots count: \(spots.count)")
                        }
                    }
                }
            }
            
//            for index in 0...3 {
//                if let spotName = data.childSnapshot(forPath: "\(index)/name").value as? String {
//                    if let spotLat = data.childSnapshot(forPath: "\(index)/lat").value as? Double {
//                        if let spotLong = data.childSnapshot(forPath: "\(index)/long").value as? Double {
//                            let spot = SurfSpot(id: index, name: spotName, lat: spotLat, long: spotLong)
//                            print("id: \(spot.id), name: \(spot.name), lat: \(spot.lat), long: \(spot.long)")
//                            spots.append(spot)
//                            print("spots count: \(spots.count)")
//                        }
//                    }
//                }
//            }
            print("spots count after for: \(spots.count)")
            callback(spots)
        }
    }
    
    class func getSpot(withId id: Int, callback: @escaping (SurfSpot) -> Void) {
        var spot: SurfSpot?
        
        let ref = FIRDatabase.database().reference(withPath: "surf_spots/\(id)")
        ref.observe(.value) {
            (data: FIRDataSnapshot) in
            print("found spot with id: \(id)")
            
            if let spotName = data.childSnapshot(forPath: "/name").value as? String {
                if let spotLat = data.childSnapshot(forPath: "/lat").value as? Double {
                    if let spotLong = data.childSnapshot(forPath: "/long").value as? Double {
                        spot = SurfSpot(id: id, name: spotName, lat: spotLat, long: spotLong)
                        print("created spot: \(spotName)")
                        callback(spot!)
                    }
                }
            }
        }
    }
}
