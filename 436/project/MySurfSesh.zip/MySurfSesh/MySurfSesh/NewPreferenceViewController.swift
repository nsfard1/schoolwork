//
//  NewPreferenceViewController.swift
//  MySurfSesh
//
//  Created by Nathan Sfard on 3/16/17.
//  Copyright © 2017 Nathan. All rights reserved.
//

import Foundation
import UIKit

class NewPreferenceViewController: UIViewController {
    
}
